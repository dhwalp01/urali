<?php $__env->startSection('title'); ?>
    <?php echo e(__('404 | Not Found')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Title-->
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumbs">
                        <li><a href="<?php echo e(route('front.index')); ?>"><?php echo e(__('Home')); ?></a> </li>
                        <li class="separator"></li>
                        <li><?php echo e(__('404 | Not Found')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <section class="fourzerofour py-5 my-5">
        <div class="container py-5 mt-5 mb-3">
          <div class="row">
            <div class="col-lg-12">
              <div class="content text-center">
                <h3 class="heading">
                  <strong><?php echo e(__('404 | Not Found')); ?></strong>
                </h3>
                <p class="text">
                  <?php echo e(__('The resource request could not be found on this server !')); ?>

                </p>
                <a href="<?php echo e(route('front.index')); ?>">
                  <button class="btn btn-primary">
                    <span><?php echo e(__('Back Home')); ?></span>
                  </button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('master.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dhawalpatel/Desktop/laravel/urali-ecomm/resources/views/errors/404.blade.php ENDPATH**/ ?>